class Myuser{
  final String uid;
Myuser({required this.uid });
}