class AppConstants {
   final String appName = "OxyZone" ;
 final String slogan = "Delivery App";
 final String login = "LOGIN";
 final String forgetText ="Forget Password?";


  
}

