import 'package:flutter/material.dart';

Color primarycolor =const  Color(0xff08c105);
// sir we do add colors like this along with 0x right ..from where do we take this sir